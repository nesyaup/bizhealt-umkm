# Tutorial Redesain BizHealt (Klasik · Minimalis · Biru Pastel + Putih)

## 1. Menjalankan website
1. Ekstrak ZIP, taruh folder di `htdocs` (XAMPP/InfinityFree) agar PHP backend jalan.
2. Buka `http://localhost/BizHealt-main/html/index.html`.
3. Backend & database tidak berubah: import `backend/database.sql`, atur `backend/php/config.php` seperti sebelumnya.
   (Untuk hanya melihat tampilan: `python3 -m http.server` di folder proyek, buka `/html/index.html`.)

## 2. File yang diubah
| File | Perubahan |
|---|---|
| `html/index.html` | Nama jadi **BizHealt**, font Lora (serif) + Inter, warna inline |
| `css/main.css` | Token warna baru di `:root` + blok `BIZHEALT THEME` di bagian akhir (dashboard) |
| `css/auth.css` | Blok `BIZHEALT THEME` di akhir (landing, login, daftar) |
| `js/main.js`, `js/form.js`, `js/auth.js` | Warna grafik & kartu inline, nama BizHealt |

> Folder `Frontend/` adalah salinan lama; yang dipakai halaman aktif adalah `html/` + `css/` + `js/`.

## 3. Palet warna
| Token | Hex | Pemakaian |
|---|---|---|
| `--pastel-100` | `#f3f8fd` | hover, header tabel |
| `--pastel-200` | `#eaf2fb` | latar banner, menu aktif |
| `--pastel-300` | `#dce9f7` | badge, avatar |
| `--pastel-400` | `#b9d3ee` | garis aksen |
| `--primary` | `#4a78ab` | tombol, link |
| `--primary-deep` | `#2c4a6e` | judul, logo |
| `--gray-*` | abu kebiruan | teks & border |

Ingin biru lebih muda/tua? Ubah nilai di `:root` pada `css/main.css` (dan hex yang sama di `css/auth.css`).

## 4. Prinsip desain yang diterapkan
- **Klasik**: judul memakai serif *Lora*, isi memakai *Inter*; font-weight diturunkan ke 600.
- **Minimalis**: tanpa gradient gelap & bayangan; kartu datar berborder tipis, sudut 4–6px.
- **Putih dominan**: latar halaman putih, biru pastel hanya untuk penekanan.

## 5. Mengganti font
Di `html/index.html` ubah link Google Fonts, lalu ubah `--font-serif` / `--font-body` di `:root`.

## 6. Nama BizHealt
Semua teks yang terlihat (judul tab, logo, landing, footer, email contoh, nama file unduhan CSV) sudah menjadi BizHealt.
Sengaja **tidak** diubah agar data tidak rusak: key localStorage `nexa_token`, nama database `nexaumkm`, dan `JWT_SECRET`. Jika mengganti nama database, ubah di `config.php` & `database.sql`.

## 7. Menyesuaikan lebih lanjut
- Sudut lebih tegas/halus: `--radius` di `:root`.
- Kembalikan bayangan: `--shadow`.
- Warna grafik (Chart.js): cari `#4a78ab`/`#7fa6d1`/`#b9d3ee` di `js/main.js`.
- Cadangan file asli ada di ZIP awal Anda.
